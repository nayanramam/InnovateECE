set_clock_latency -source -early -min   -0.0021 [get_ports {clk}] -clock core_clock 
set_clock_latency -source -early -max   -0.0021 [get_ports {clk}] -clock core_clock 
set_clock_latency -source -late -min   -0.0021 [get_ports {clk}] -clock core_clock 
set_clock_latency -source -late -max   -0.0021 [get_ports {clk}] -clock core_clock 
