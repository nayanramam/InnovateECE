# ####################################################################

#  Created by Genus(TM) Synthesis Solution 25.11-s095_1 on Fri Mar 13 13:30:55 EDT 2026

# ####################################################################

set sdc_version 2.0

set_units -capacitance 1000fF
set_units -time 1000ps

# Set the current design
current_design counter_16bit

create_clock -name "core_clock" -period 25.0 -waveform {0.0 12.5} [get_ports clk]
set_clock_transition 0.15 [get_clocks core_clock]
set_load -pin_load 0.0334 [get_ports clk]
set_load -pin_load 0.0334 [get_ports rst_n]
set_load -pin_load 0.0334 [get_ports enable]
set_load -pin_load 0.0334 [get_ports {count[15]}]
set_load -pin_load 0.0334 [get_ports {count[14]}]
set_load -pin_load 0.0334 [get_ports {count[13]}]
set_load -pin_load 0.0334 [get_ports {count[12]}]
set_load -pin_load 0.0334 [get_ports {count[11]}]
set_load -pin_load 0.0334 [get_ports {count[10]}]
set_load -pin_load 0.0334 [get_ports {count[9]}]
set_load -pin_load 0.0334 [get_ports {count[8]}]
set_load -pin_load 0.0334 [get_ports {count[7]}]
set_load -pin_load 0.0334 [get_ports {count[6]}]
set_load -pin_load 0.0334 [get_ports {count[5]}]
set_load -pin_load 0.0334 [get_ports {count[4]}]
set_load -pin_load 0.0334 [get_ports {count[3]}]
set_load -pin_load 0.0334 [get_ports {count[2]}]
set_load -pin_load 0.0334 [get_ports {count[1]}]
set_load -pin_load 0.0334 [get_ports {count[0]}]
set_clock_gating_check -setup 0.0 
set_max_transition 1.5 [get_ports clk]
set_max_transition 1.5 [get_ports rst_n]
set_max_transition 1.5 [get_ports enable]
set_max_transition 1.5 [get_ports {count[15]}]
set_max_transition 1.5 [get_ports {count[14]}]
set_max_transition 1.5 [get_ports {count[13]}]
set_max_transition 1.5 [get_ports {count[12]}]
set_max_transition 1.5 [get_ports {count[11]}]
set_max_transition 1.5 [get_ports {count[10]}]
set_max_transition 1.5 [get_ports {count[9]}]
set_max_transition 1.5 [get_ports {count[8]}]
set_max_transition 1.5 [get_ports {count[7]}]
set_max_transition 1.5 [get_ports {count[6]}]
set_max_transition 1.5 [get_ports {count[5]}]
set_max_transition 1.5 [get_ports {count[4]}]
set_max_transition 1.5 [get_ports {count[3]}]
set_max_transition 1.5 [get_ports {count[2]}]
set_max_transition 1.5 [get_ports {count[1]}]
set_max_transition 1.5 [get_ports {count[0]}]
set_clock_uncertainty -setup 0.25 [get_clocks core_clock]
set_clock_uncertainty -hold 0.25 [get_clocks core_clock]
