######################################################################

# Created by Genus(TM) Synthesis Solution 25.11-s095_1 on Mon Mar 16 12:26:08 EDT 2026

# This file contains the Genus script for design:Core

######################################################################

set_db -quiet set_units_set true
set_db -quiet hdl_unconnected_marking_done true
set_db -quiet dont_break_combo_loops_thr_c_to_q true
set_db -quiet dont_break_combo_loops_thr_c_to_q_macro true
set_db -quiet dont_break_combo_loops_thr_en_to_q true
set_db -quiet design_mode_process 140.0
set_db -quiet phys_assume_met_fill 0.0
set_db -quiet map_placed_for_route_early_global false
set_db -quiet phys_use_invs_extraction true
set_db -quiet phys_route_time_out 120.0
set_db -quiet capacitance_per_unit_length_mmmc {}
set_db -quiet resistance_per_unit_length_mmmc {}
set_db -quiet lp_insert_clock_gating true
set_db -quiet runtime_by_stage {{PBS_Generic-earlyCG 2 73 1.9922459999999944 65.992246} {to_generic 37 113 39 108} {first_condense 23 141 27 142} {PBS_Generic_Opt-Post 70 145 69.877777 137.868204} {{PBS_Generic-Postgen HBO Optimizations} 0 145 1.0 138.868204} {PBS_Generic-earlyCG_cleanup 0 147 1.0 140.868204} {PBS_TechMap-Start 0 52 0.0 45.994822} {{PBS_TechMap-Premap HBO Optimizations} 1 53 0.0 45.994822} {second_condense 27 80 29 76} {reify 35 115 45 121} {global_incr_map 9 124 11 133} {{PBS_Techmap-Global Mapping} 81 134 77.28859599999998 123.28341799999998} {{PBS_TechMap-Datapath Postmap Operations} 7 141 5.788494000000014 129.071912} {{PBS_TechMap-Postmap HBO Optimizations} 0 141 0.8002989999999954 129.872211} {{PBS_TechMap-Postmap Clock Gating} 1 142 1.0 130.872211} {{PBS_TechMap-Postmap Cleanup} 1 143 0.7903760000000091 131.662587} {PBS_Techmap-Post_MBCI 0 143 0.0 131.662587} {incr_opt 24 75 25 68} }
set_db -quiet timing_adjust_tns_of_complex_flops false
set_db -quiet tim_complex_use_dense false
set_db -quiet tim_complex_use_prevs true
set_db -quiet dft_ignore_segment_mode_name false
set_db -quiet dft_lpc_allow_additional_signal_functions false
set_db -quiet dft_use_ungated_clock_for_testpoint true
set_db -quiet cts_buffer_cells {CLKBUFX2 CLKBUFX4 CLKBUFX8}
set_db -quiet cts_inverter_cells {CLKINVX1 CLKINVX2 CLKINVX4 CLKINVX8}
set_db -quiet cts_clock_gating_cells ICGX1
set_db -quiet cts_logic_cells {CLKAND2X2 CLKXOR2X1 CLKMX2X2 CLKINVX1 CLKINVX2 CLKINVX4 CLKINVX8}
set_db -quiet tinfo_tstamp_file .rs_dkhalil8.tstamp
set_db -quiet common_preserve_skip_internal true
set_db -quiet exp_within_stylus_db 1
set_db -quiet flow_template_type stylus
set_db -quiet flow_template_tools {genus innovus tempus quantus voltus}
set_db -quiet flow_template_version 1
set_db -quiet flow_template_feature_definition {flow_express 0 report_inline {} report_defer 0 report_none 0 report_clp 0 report_lec {} use_common_db 0 report_pba {} dft_simple 0 dft_compressor 0 synth_hybrid 0 synth_ispatial 0 synth_placev2 0 opt_early_cts 0 clock_design 0 clock_flexible_htree 0 opt_clock 0 opt_postcts_hold_disable 0 opt_postcts_split 0 route_filler_disable 0 route_track_opt 0 route_secondary_nets 0 opt_postroute_split 0 opt_route 0 opt_signoff {} opt_em 0 opt_eco 0 sta_use_setup_yaml 0 sta_dmmmc 0 sta_glitch 0 sta_eco 0 report_early_static_ir 0 report_early_dynamic_ir 0 report_grid_resistance 0 report_static_ir {} report_dynamic_ir {} report_rampup 0 report_signal_em 0 report_power_em 0 report_power_parallel 0 ff_setup 0}
set_db -quiet flow_features {report_inline {feature report_inline required 0 takes_value 0 valid_values {} default 0 desc {Run report generation as part of parent flow versus schedule_flow}} report_lec {feature report_lec required 0 takes_value 0 valid_values {} default 0 desc {Add LEC dofile generation and checks to the flow}} report_pba {feature report_pba required 0 takes_value 0 valid_values {} default 0 desc {Enable PBA analysis and report generation}} opt_signoff {feature opt_signoff required 0 takes_value 0 valid_values {} default 0 desc {Run opt_signoff during implementation flow}} report_static_ir {feature report_static_ir required 0 takes_value 0 valid_values {} default 0 desc {Report static rail analysis}} report_dynamic_ir {feature report_dynamic_ir required 0 takes_value 0 valid_values {} default 0 desc {Report dynamic rail analysis}} setup_views {feature setup_views required 0 takes_value 1 valid_values {} default {} desc {list of setup analysis_views to activate}} hold_views {feature hold_views required 0 takes_value 1 valid_values {} default {} desc {list of hold analysis_views to activate}} dynamic_view {feature dynamic_view required 0 takes_value 1 valid_values {} default {} desc {single dynamic analysis_view to activate}} leakage_view {feature leakage_view required 0 takes_value 1 valid_values {} default {} desc {single leakage analysis_view to activate}}}
set_db -quiet flow_feature_values {report_inline 0 report_lec 0 report_pba 0 opt_signoff 0 report_static_ir 0 report_dynamic_ir 0 setup_views {} hold_views {} dynamic_view {} leakage_view {}}
set_db -quiet flow_plugin_steps {{before Cadence.plugin.flowkit.read_db.post flow_step:activate_views} {before Cadence.plugin.flowkit.read_db.pre flow_step:activate_views} {after Cadence.plugin.flowkit.read_db.pre flow_step:init_mcpu} {after Cadence.plugin.flowkit.read_db.post flow_step:init_mcpu}}
set_db -quiet flow_status_file flow.status.d/syn_opt
set_db -quiet flow_starting_db {rc dbs/syn_map.db Core {}}
set_db -quiet flow_top flow:flow_current
set_db -quiet flow_metrics_file flow.metrics.d/syn_opt
set_db -quiet flow_caller_data {group 0 process_branch 0 trunk_process 1 flowtool_hostname ece-rschsrv.ece.gatech.edu flowtool_pid 1323878}
set_db -quiet flow_step_canonical_current {tool genus flow flow:flow_current canonical_path {.steps flow:synthesis .steps flow:syn_opt .steps flow_step:block_finish} step flow_step:block_finish features {} str synthesis.syn_opt.block_finish}
set_db -quiet flow_step_current flow_step:block_finish
set_db -quiet flow_hier_path {flow:flow_current flow:synthesis flow:syn_opt}
set_db -quiet flow_remark {}
set_db -quiet flowtool_metrics_qor_vivid reports/qor.html
set_db -quiet flow_header_tcl {
  #- extend flow report name based on context
  if {[is_flow -quiet -inside flow:sta] || [is_flow -quiet -inside flow:sta_dmmmc] || [is_flow -quiet -inside flow:sta_eco]} {
    if {![regexp {sta$} [get_db flow_report_name]]} {
      set_db flow_report_name [expr {[string is space [get_db flow_report_name]] ? "sta" : "[get_db flow_report_name].sta"}]
    }
  } elseif {[is_flow -quiet -inside flow:ir_early_static] || [is_flow -quiet -inside flow:ir_early_dynamic]} {
    if {![regexp {era$} [get_db flow_report_name]]} {
      set_db flow_report_name [expr {[string is space [get_db flow_report_name]] ? "era" : "[get_db flow_report_name].era"}]
    }
  } elseif {[is_flow -quiet -inside flow:ir_grid] || [is_flow -quiet -inside flow:ir_static] || [is_flow -quiet -inside flow:ir_dynamic] || [is_flow -quiet -inside flow:ir_rampup]} {
    if {![regexp {ir$} [get_db flow_report_name]]} {
      set_db flow_report_name [expr {[string is space [get_db flow_report_name]] ? "ir" : "[get_db flow_report_name].ir"}]
    }
  } elseif {[is_flow -quiet -inside flow:sta_subflows] && [get_db flow_branch] ne {}} {
    set_db flow_report_name [get_db flow_branch]
  } elseif {[regexp {block_start|hier_start|eco_start} [get_db flow_step_current]]} {
    set_db flow_report_name [get_db [lindex [get_db flow_hier_path] end] .name]
  } else {
  }

  #- Create report dir (if necessary)
  file mkdir [file normalize [file join [get_db flow_report_directory] [get_db flow_report_name]]]
}
set_db -quiet flow_step_last_status success
set_db -quiet flow_history {{step {tool genus flow {.name plugin .tool genus} canonical_path {.start_steps flow_step:activate_views} step flow_step:activate_views features {} str activate_views} status success msg {}} {step {tool genus flow {.name plugin .tool genus} canonical_path {.end_steps flow_step:init_mcpu} step flow_step:init_mcpu features {} str init_mcpu} status success msg {}} {step {tool genus flow {.name plugin .tool genus} canonical_path {.start_steps flow_step:activate_views} step flow_step:activate_views features {} str activate_views} status success msg {}} {step {tool genus flow {.name plugin .tool genus} canonical_path {.end_steps flow_step:init_mcpu} step flow_step:init_mcpu features {} str init_mcpu} status success msg {}} {step {tool genus flow flow:flow_current canonical_path {.steps flow:synthesis .steps flow:syn_generic .steps flow_step:block_start} step flow_step:block_start features {} str synthesis.syn_generic.block_start} status success msg {}} {step {tool genus flow flow:flow_current canonical_path {.steps flow:synthesis .steps flow:syn_generic .steps flow_step:init_elaborate} step flow_step:init_elaborate features {} str synthesis.syn_generic.init_elaborate} status success msg {}} {step {tool genus flow flow:flow_current canonical_path {.steps flow:synthesis .steps flow:syn_generic .steps flow:init_design .steps flow_step:read_mmmc} step flow_step:read_mmmc features {} str synthesis.syn_generic.init_design.read_mmmc} status success msg {}} {step {tool genus flow flow:flow_current canonical_path {.steps flow:synthesis .steps flow:syn_generic .steps flow:init_design .steps flow_step:read_physical} step flow_step:read_physical features {} str synthesis.syn_generic.init_design.read_physical} status success msg {}} {step {tool genus flow flow:flow_current canonical_path {.steps flow:synthesis .steps flow:syn_generic .steps flow:init_design .steps flow_step:read_hdl} step flow_step:read_hdl features {} str synthesis.syn_generic.init_design.read_hdl} status success msg {}} {step {tool genus flow flow:flow_current canonical_path {.steps flow:synthesis .steps flow:syn_generic .steps flow:init_design .steps flow_step:read_power_intent} step flow_step:read_power_intent features {} str synthesis.syn_generic.init_design.read_power_intent} status success msg {}} {step {tool genus flow flow:flow_current canonical_path {.steps flow:synthesis .steps flow:syn_generic .steps flow:init_design .steps flow_step:run_init_design} step flow_step:run_init_design features {} str synthesis.syn_generic.init_design.run_init_design} status success msg {}} {step {tool genus flow flow:flow_current canonical_path {.steps flow:synthesis .steps flow:syn_generic .steps flow:init_genus .steps flow_step:init_genus_yaml} step flow_step:init_genus_yaml features {} str synthesis.syn_generic.init_genus.init_genus_yaml} status success msg {}} {step {tool genus flow flow:flow_current canonical_path {.steps flow:synthesis .steps flow:syn_generic .steps flow:init_genus .steps flow_step:init_genus_user} step flow_step:init_genus_user features {} str synthesis.syn_generic.init_genus.init_genus_user} status success msg {}} {step {tool genus flow flow:flow_current canonical_path {.steps flow:synthesis .steps flow:syn_generic .steps flow_step:set_dont_use} step flow_step:set_dont_use features {} str synthesis.syn_generic.set_dont_use} status success msg {}} {step {tool genus flow flow:flow_current canonical_path {.steps flow:synthesis .steps flow:syn_generic .steps flow_step:commit_power_intent} step flow_step:commit_power_intent features {} str synthesis.syn_generic.commit_power_intent} status success msg {}} {step {tool genus flow flow:flow_current canonical_path {.steps flow:synthesis .steps flow:syn_generic .steps flow_step:run_syn_generic} step flow_step:run_syn_generic features {} str synthesis.syn_generic.run_syn_generic} status success msg {}} {step {tool genus flow flow:flow_current canonical_path {.steps flow:synthesis .steps flow:syn_generic .steps flow_step:block_finish} step flow_step:block_finish features {} str synthesis.syn_generic.block_finish} status success msg {}} {step {tool genus flow {.name plugin .tool genus} canonical_path {.start_steps flow_step:activate_views} step flow_step:activate_views features {} str activate_views} status success msg {}} {step {tool genus flow {.name plugin .tool genus} canonical_path {.end_steps flow_step:init_mcpu} step flow_step:init_mcpu features {} str init_mcpu} status success msg {}} {step {tool genus flow flow:flow_current canonical_path {.steps flow:synthesis .steps flow:syn_map .steps flow_step:block_start} step flow_step:block_start features {} str synthesis.syn_map.block_start} status success msg {}} {step {tool genus flow flow:flow_current canonical_path {.steps flow:synthesis .steps flow:syn_map .steps flow:init_genus .steps flow_step:init_genus_yaml} step flow_step:init_genus_yaml features {} str synthesis.syn_map.init_genus.init_genus_yaml} status success msg {}} {step {tool genus flow flow:flow_current canonical_path {.steps flow:synthesis .steps flow:syn_map .steps flow:init_genus .steps flow_step:init_genus_user} step flow_step:init_genus_user features {} str synthesis.syn_map.init_genus.init_genus_user} status success msg {}} {step {tool genus flow flow:flow_current canonical_path {.steps flow:synthesis .steps flow:syn_map .steps flow_step:run_syn_map} step flow_step:run_syn_map features {} str synthesis.syn_map.run_syn_map} status success msg {}} {step {tool genus flow flow:flow_current canonical_path {.steps flow:synthesis .steps flow:syn_map .steps flow_step:block_finish} step flow_step:block_finish features {} str synthesis.syn_map.block_finish} status success msg {}} {step {tool genus flow {.name plugin .tool genus} canonical_path {.start_steps flow_step:activate_views} step flow_step:activate_views features {} str activate_views} status success msg {}} {step {tool genus flow {.name plugin .tool genus} canonical_path {.end_steps flow_step:init_mcpu} step flow_step:init_mcpu features {} str init_mcpu} status success msg {}} {step {tool genus flow flow:flow_current canonical_path {.steps flow:synthesis .steps flow:syn_opt .steps flow_step:block_start} step flow_step:block_start features {} str synthesis.syn_opt.block_start} status success msg {}} {step {tool genus flow flow:flow_current canonical_path {.steps flow:synthesis .steps flow:syn_opt .steps flow:init_genus .steps flow_step:init_genus_yaml} step flow_step:init_genus_yaml features {} str synthesis.syn_opt.init_genus.init_genus_yaml} status success msg {}} {step {tool genus flow flow:flow_current canonical_path {.steps flow:synthesis .steps flow:syn_opt .steps flow:init_genus .steps flow_step:init_genus_user} step flow_step:init_genus_user features {} str synthesis.syn_opt.init_genus.init_genus_user} status success msg {}} {step {tool genus flow flow:flow_current canonical_path {.steps flow:synthesis .steps flow:syn_opt .steps flow_step:run_syn_opt} step flow_step:run_syn_opt features {} str synthesis.syn_opt.run_syn_opt} status success msg {}} {step {tool genus flow flow:flow_current canonical_path {.steps flow:synthesis .steps flow:syn_opt .steps flow_step:block_finish} step flow_step:block_finish features {} str synthesis.syn_opt.block_finish} status success msg {}}}
set_db -quiet max_cpus_per_server 16
set_db -quiet ocv_mode true
set_db -quiet use_area_from_lef true
set_db -quiet shrink_factor 1.0
set_db -quiet number_of_routing_layers 5
set_db -quiet flow_step_last flow_step:block_finish
set_db -quiet flow_step_next {tool genus flow flow:flow_current canonical_path {.steps flow:synthesis .steps flow:syn_opt .steps flow_step:schedule_syn_opt_report_synth} step flow_step:schedule_syn_opt_report_synth features {} str synthesis.syn_opt.schedule_syn_opt_report_synth}
set_db -quiet flow_metrics_snapshot_uuid fb1738cc-1a8c-4a70-8208-0547112e3c4c
set_db -quiet read_qrc_tech_file_rc_corner true
set_db -quiet heartbeat 300
set_db -quiet flow_report_name syn_opt
set_db -quiet flow_spef_directory dbs/syn_opt
set_db -quiet inst:Core/InstructionFetch_Module_InstructionMemory_instr_sram .hdl_instantiated true
set_db -quiet inst:Core/MainMemory_data_sram .hdl_instantiated true
# there is no hdl_instantiated attribute information available
set_db -quiet source_verbose true
