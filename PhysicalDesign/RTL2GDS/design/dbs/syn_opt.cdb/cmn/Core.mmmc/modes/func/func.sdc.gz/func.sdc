# ####################################################################

#  Created by Genus(TM) Synthesis Solution 25.11-s095_1 on Mon Mar 23 21:43:21 EDT 2026

# ####################################################################

set sdc_version 2.0

set_units -capacitance 1000fF
set_units -time 1000ps

# Set the current design
current_design Core

create_clock -name "core_clock" -period 10.0 -waveform {0.0 5.0} [get_ports clock]
set_clock_transition 0.15 [get_clocks core_clock]
set_load -pin_load 0.0334 [get_ports clock]
set_load -pin_load 0.0334 [get_ports reset]
set_load -pin_load 0.0334 [get_ports mem_en]
set_clock_gating_check -setup 0.0 
set_max_transition 1.5 [get_ports clock]
set_max_transition 1.5 [get_ports reset]
set_max_transition 1.5 [get_ports mem_en]
set_max_dynamic_power 5000000.0
set_clock_uncertainty -setup 0.25 [get_clocks core_clock]
set_clock_uncertainty -hold 0.25 [get_clocks core_clock]
## List of unsupported SDC commands ##
set_max_dynamic_power 5 mW
