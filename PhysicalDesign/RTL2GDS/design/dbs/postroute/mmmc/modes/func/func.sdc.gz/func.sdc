current_design Core
set_clock_gating_check -rise -setup 0 
set_clock_gating_check -fall -setup 0 
set_units -time 1ns -capacitance 1pf
create_clock [get_ports {clock}]  -name core_clock -period 25.000000 -waveform {0.000000 12.500000}
set_clock_transition  -rise -min 0.15 [get_clocks {core_clock}]
set_clock_transition  -rise -max 0.15 [get_clocks {core_clock}]
set_clock_transition  -fall -min 0.15 [get_clocks {core_clock}]
set_clock_transition  -fall -max 0.15 [get_clocks {core_clock}]
set_propagated_clock  [get_ports {clock}]
#END OF CLOCK SECTION#
set_load -pin_load -max  0.0334  [get_ports {clock}]
set_load -pin_load -min  0.0334  [get_ports {clock}]
set_max_transition 1.5  [get_ports {clock}]
set_load -pin_load -max  0.0334  [get_ports {reset}]
set_load -pin_load -min  0.0334  [get_ports {reset}]
set_max_transition 1.5  [get_ports {reset}]
set_load -pin_load -max  0.0334  [get_ports {mem_en}]
set_load -pin_load -min  0.0334  [get_ports {mem_en}]
set_max_transition 1.5  [get_ports {mem_en}]
set_clock_uncertainty 0.25 [get_clocks {core_clock}]
